
/**
 * Module dependencies.
 */
var app = require('./app.js');

app.startServer();