/** Setting the angular module **/

angular.module('BankApp',['ui.router']);
